﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using accounting.classes;
using AccountingLib.Models;
using accounting.classes.enums;

namespace accounting.classes
{
    public class Currency 
    {
        public int currencyID;
        public readonly int CURRENCYTYPEID;

        public void create(string CurrencyName, int currencyTypeID)
        {
            using (var ctx = new AccContexts())
                {
                    var newCur = new AccountingLib.Models.currency
                    {
                        currencyTypeID = currencyTypeID,
                        name = CurrencyName
                    };
                    var result = ctx.currency.FirstOrDefault(x => x.name == CurrencyName && x.currencyType.ID == currencyTypeID);
                    if (result != null)
                        throw new Exception("Currency Duplicated");
                    else
                    {   
                        ctx.currency.AddObject(newCur);
                        ctx.SaveChanges();

                        this.currencyID = newCur.ID;
                    }
                }
           
        }

        
    }
}
