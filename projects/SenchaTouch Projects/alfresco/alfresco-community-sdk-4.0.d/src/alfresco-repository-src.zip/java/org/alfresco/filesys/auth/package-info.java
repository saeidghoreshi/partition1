/**
 */
package org.alfresco.filesys.auth;
