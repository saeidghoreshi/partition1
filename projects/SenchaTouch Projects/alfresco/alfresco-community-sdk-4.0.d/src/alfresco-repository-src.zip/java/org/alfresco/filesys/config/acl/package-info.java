/**
 */
package org.alfresco.filesys.config.acl;
