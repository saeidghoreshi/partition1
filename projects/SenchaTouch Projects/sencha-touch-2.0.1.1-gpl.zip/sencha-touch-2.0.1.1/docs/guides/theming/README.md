# Theming Sencha Touch

{@video vimeo 36917216}

This tutorial is perfect for beginners who want to get started customizing the interface of their Sencha Touch mobile
app using CSS3 and Sass/SCSS.

View the source code on GitHub: <a href="http://github.com/senchalearn/Touch-Theming">github.com/senchalearn/Touch-Theming</a>

View live demo: <a href="http://senchalearn.github.com/Touch-Theming/">senchalearn.github.com/Touch-Theming/</a>
